import React, { useState } from 'react';

function App() {
  // Definimos el estado inicial del contador
  const [contador, setContador] = useState(0);

  // Función para restar 1 al contador
  const handleSubtract = () => {
    setContador(contador - 1);
  };

  // Función para restablecer el contador a su valor inicial
  const handleReset = () => {
    setContador(0);
  };

  return (
    <div>
      <h1>Contador de Noticias: {contador}</h1>
      <button onClick={handleSubtract}>Restar 1</button>
      <button onClick={handleReset}>Resetear</button>
    </div>
  );
}

export default App;
