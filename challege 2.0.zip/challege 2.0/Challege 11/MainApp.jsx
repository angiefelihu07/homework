// MainApp.jsx

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AppRoutes from './AppRoutes';
import PrivateRoutes from './PrivateRoutes';

const MainApp = () => {
  return (
    <div>
      {/* Other layout elements or components can go here */}
      <Routes>
        <Route
          path="/*"
          element={
            <PrivateRoutes
              element={<AppRoutes />}
            />
          }
        />
      </Routes>
    </div>
  );
};

export default MainApp;

