// UserRoutes.jsx

import React from 'react';
import { Routes, Route } from 'react-router-dom';

const UserRoutes = () => {
  return (
    <Routes>
      {/* Add user-related routes here */}
    </Routes>
  );
};

export default UserRoutes;
