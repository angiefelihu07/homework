// ProductsPage.jsx

import React from 'react';
import { useNavigate } from 'react-router-dom';

const ProductsPage = () => {
  const navigate = useNavigate();

  const onLogout = () => {
    navigate('/login', {
      replace: true,
    });
  };

  return (
    <div>
      {/* Content of the ProductsPage goes here */}
      <button onClick={onLogout}>Logout</button>
    </div>
  );
};

export default ProductsPage;
