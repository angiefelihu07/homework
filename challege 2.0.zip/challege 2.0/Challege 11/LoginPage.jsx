// LoginPage.jsx

import React from 'react';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const navigate = useNavigate();

  const onLogin = () => {
    // Perform authentication logic

    // Get the last visited page from localStorage
    const lastVisitedPage = localStorage.getItem('lastVisitedPage');

    // Redirect to the last visited page or a default page
    navigate(lastVisitedPage || '/dashboard');

    // Clear the lastVisitedPage in localStorage
    localStorage.removeItem('lastVisitedPage');
  };

  return (
    <div>
      {/* Login form and other components go here */}
      <button onClick={onLogin}>Login</button>
    </div>
  );
};

export default LoginPage;
