// AppRoutes.jsx

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ProductsPage from './ProductsPage';
import UserRoutes from './UserRoutes';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/products/*" element={<ProductsPage />} />
      {/* Add other routes as needed */}
      <Route path="/users/*" element={<UserRoutes />} />
    </Routes>
  );
};

export default AppRoutes;
