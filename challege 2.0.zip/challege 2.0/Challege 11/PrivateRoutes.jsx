// PrivateRoutes.jsx

import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

const PrivateRoutes = ({ element }) => {
  // Check if the user is authenticated (you can replace this with your authentication logic)
  const isAuthenticated = true; // Replace with your authentication check

  if (!isAuthenticated) {
    // Redirect to the login page if not authenticated
    return <Navigate to="/login" />;
  }

  return <Routes>{element}</Routes>;
};

export default PrivateRoutes;
