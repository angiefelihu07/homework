// PokemonApp.jsx

import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { decrement, incrementBy } from '../store/slices/pokemon/pokemonSlice';

const PokemonApp = () => {
  const dispatch = useDispatch();
  const count = useSelector((state) => state.pokemon.count);

  return (
    <div>
      <h1>Pokemon Counter: {count}</h1>
      <button onClick={() => dispatch(decrement())}>Decrement</button>
      <button onClick={() => dispatch(incrementBy(5))}>Increment by 5</button>
    </div>
  );
};

export default PokemonApp;
