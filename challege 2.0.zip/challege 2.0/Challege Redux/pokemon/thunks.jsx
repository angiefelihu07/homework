// thunks.jsx

import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

// Ejemplo de thunk asíncrono
export const fetchData = createAsyncThunk('pokemon/fetchData', async () => {
  const response = await axios.get('https://api.example.com/data');
  return response.data;
});
