import React from 'react'
import { useDispatch } from 'react-redix'
import { useForm } from './useForm'
import { registerAuth } from './thunks'

export const Registro = () => {

    const dispatch = useDispatch()

    const { email, password, onInputChange, formState } = useForm({
        email: 'angie.feligrana@uao.edu.co',
        password:'America15.00'
    })

    const onSubmit = ( event ) => {
        event.preventDefault()
        console.log(formState)
        dispatch( registerAuth( email, password ) )
    }

    return (
        <>
        <h1>Registro</h1>
        <hr />
        <form onSubmit={(event) => onsubmit(event)}>
            <input name='email' type='email' onChange={ (event)  => onInputChange(event)  } value ={email}/>
            <input name='password'  type='password' onChange={ (event) => onInputChange(event) } value={password}/>

            <button type="submit">Registro</button> 
        </form>
        </>
    )
}