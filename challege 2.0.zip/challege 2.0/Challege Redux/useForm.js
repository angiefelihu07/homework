import React, { useState } from 'react'

export const useForm = ( initialState = {}) => {
    const [ formState, setFromState] = useState( initialState )

    const onInputChange = ( evt ) => {
        setFromState({
            ...formState,
            [name]: value
        })

        const onResetForm = () => {
            setFromState ( initialState)
        
        }

        return {
            ... formState,
            formState,
            onInputChange,
            onResetForm
        }
    }

}