import React from 'react'
import ReactDom from 'react-dom/client'
import './index.css'
import { BrowserRouter } from "react-router-dom";
import { Provider } from 'react-redux'
import { store } from './10-redux/store';
import { Registro } from './10-redux/Registro';

ReactDom.createRoot(Document.getElementById( 'root')).render(
    <Provider store={store}>
        <BrowserRouter>
        <Registro />
        </BrowserRouter>
    </Provider>
)