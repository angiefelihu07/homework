// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getauth } from 'firebase/auth'
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB5Q3Xmdi7HaNhPeGtNwr1Mfd-RbCsQ8zc",
  authDomain: "bdfirebase-35885.firebaseapp.com",
  projectId: "bdfirebase-35885",
  storageBucket: "bdfirebase-35885.appspot.com",
  messagingSenderId: "472531654294",
  appId: "1:472531654294:web:4d62f7cf840b3d18b9d4b7",
  measurementId: "G-9T2E1LKWSR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

//Inizialize firebase
const auth = getauth()

export { app, auth }
