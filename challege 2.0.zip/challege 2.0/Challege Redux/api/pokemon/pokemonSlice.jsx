// pokemonSlice.jsx

import { createSlice } from '@reduxjs/toolkit';

const pokemonSlice = createSlice({
  name: 'pokemon',
  initialState: {
    count: 0,
  },
  reducers: {
    decrement: (state) => {
      state.count -= 1;
    },
    incrementBy: (state, action) => {
      state.count += action.payload;
    },
  },
});

export const { decrement, incrementBy } = pokemonSlice.actions;
export default pokemonSlice.reducer;
