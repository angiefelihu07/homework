// pokemonApi.js

import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const pokemonApi = createApi({
  reducerPath: 'pokemonApi',
  baseQuery: fetchBaseQuery({ baseUrl: '/api' }), // Ajusta la URL base de tu API
  endpoints: (builder) => ({
    getPokemon: builder.query({
      query: () => 'pokemon',
    }),
  }),
});

export const { useGetPokemonQuery } = pokemonApi;
