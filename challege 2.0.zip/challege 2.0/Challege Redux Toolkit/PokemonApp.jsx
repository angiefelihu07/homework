// PokemonApp.jsx

import React from 'react';
import { Provider } from 'react-redux';
import { store } from './store/store';
import PokemonApp from './components/PokemonApp';

const App = () => {
  return (
    <Provider store={store}>
      <PokemonApp />
    </Provider>
  );
};

export default App;
