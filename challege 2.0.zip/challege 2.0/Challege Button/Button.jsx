// Button.js
import React from 'react';
import styles from './Button.module.css';

const Button = ({ onClick, children, isError }) => {
  const buttonClass = isError ? styles.error : styles.button;

  return (
    <button className={buttonClass} onClick={onClick}>
      {children}
    </button>
  );
};

export default Button;
