// TodoApp.js
import React from 'react';
import Button from './Button';
import './another-stylesheet.css';
import myImage from './images/my-image.png'; // Import the image
import myFont from './fonts/my-font.woff'; // Import the font
import myFile from './files/my-file.pdf'; // Import the file

const TodoApp = () => {
  // ... (tu código existente)

  const handleAddTODO = () => {
    const text = prompt('Enter TODO:');
    if (text) {
      addTODO(text);
    }
  };

  const handleDownloadFile = () => {
    // You can add logic here to trigger file download
    console.log('Downloading file:', myFile);
  };

  return (
    <div>
      <Button onClick={handleAddTODO} className="button-special">
        Add TODO
      </Button>
      <div>
        {todos.map((todo, index) => (
          <TodoItem
            key={index}
            index={index}
            text={todo.text}
            done={todo.done}
            onDelete={deleteTODO}
            onToggle={toggleTODO}
          />
        ))}
      </div>
      <div>
        Total TODOs: {countTodos()}, Pending TODOs: {countPendingTodos()}
      </div>
      <div>
        <img src={myImage} alt="My Image" />
      </div>
      <div>
        <a href={myFile} download onClick={handleDownloadFile}>
          Download My File
        </a>
      </div>
      <div className="error">This text is in red because of the error style.</div>
    </div>
  );
};

export default TodoApp;

