const express = require('express');
const Usuario = require('../models/Usuario');
const bcrypt = require('bcryptjs');

const crearUsuario = async (req, res = express.request ) => {
    const { name, email, password } = req.body
    try {
       let usuario = await Usuario.findOne({ email: email })
       if ( usuario ) {
        return res.status(400),json({
            ok: false,
            msg: 'El usuario con ese correo ya existe',
        })
       }

       usuario = new Usuario( req.body );
       const salt = bcrypt.genSaltSync();
       usuario.password = bcrypt.hashSync(password, salt);
       await usuario.save();

       res.status(200),json({
        ok: true,
        usuario,
       })

    } catch(error) {
        console.log( error )
        res.status(500).json({
            ok: false,
            error,
        })    
    }
}

const loginUsuario = (req, res = express.request) => {
    const { email, password } = req.body

    try {
        let usuario = await Usuario.findOne({ email: email})
        if ( !usuario ) {
            return res.status(400).json({
                ok: false,
                msg: 'El usuario NO existe',
            })
        }
        const passwordValid = bcrypt.compareSync(password, usuario.password);
        if ( !passwordValid ){
            return res.status(400).json({
                ok: false,
                msg: 'El password No es valido'
            })
        }

        res.status(200).json({
            ok: true,
            usuario, 
        })
    }
}

const revalidarToken = (req, res = express.request) => {
    res.json({
        ok: true
    })
}

module.exports = {
    loginUsuario,
    crearUsuario,
    revalidarToken
}