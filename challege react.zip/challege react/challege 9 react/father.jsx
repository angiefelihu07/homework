import React from 'react'
import { useReducer } from 'react'
import { todoReducer} from 'react'

const initialState = [{
    id: new Date().getTime(),
    description: 'Hacer los challeges',
    done: false
}]

export const TodoApp = () => {
    const [todos,dispacthTodo] = useReducer(todoReducer, initialState)
    
    return(
        <>
        <h1>
            TodoApp: 10, <small> Pendientes:2 </Pendientes:2></small>
        </h1>

    <hr />

    <div className="row">
        <div className="col-7">
            
        </div>
    </div>
        </>
    )
}