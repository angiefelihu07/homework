// TitleComponent.jsx

import React from 'react';

function TitleComponent() {
  return (
    <div>
      <h1>Título</h1>
      <span>10</span>
    </div>
  );
}

export default TitleComponent;
